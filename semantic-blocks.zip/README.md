# Semantic Blocks

`A work in progress.`

## Requirements

**WordPress 5.0.0 or newer**

## Installing

**Manually**

1. Download ZIP file from repository
2. Uplaod to `wp-content/plugins` directory via SFTP
3. Unpack ZIP file
4. Activate plugin via WordPress Plugins page

**WordPress Plugin Install**

1. Download ZIP file from repository
2. Visit WordPress Plugins page and click "Add new"
3. Upload ZIP file
4. Activate plugin via WordPress Plugins page
